SKILLUP ACADEMY — 8-WEEK MARKETING ANALYTICS PROJECT

Files:
1. Week_1-2_Marketing_Metrics_Framework.docx
   - 5-page style marketing metrics framework with definitions, formulas, examples and funnel measurement.

2. SkillUp_Academy_Marketing_Dashboard.xlsx
   - Raw data
   - Calculated metrics
   - Channel summary
   - Monthly summary
   - Dashboard with KPI cards, funnel and charts

3. Week_3-4_Marketing_Dashboard_Report.docx
   - Dataset explanation, KPI definitions, visualisation rationale and data-quality notes.

4. Week_5-6_Attribution_Analysis.xlsx
   - Customer journeys
   - First-touch, last-touch and linear calculations
   - Attribution summary and chart

5. Week_5-6_Marketing_Attribution_Analysis.docx
   - 4–5 page style attribution analysis with model comparison and management implications.

6. Week_7-8_Final_Management_Report.docx
   - Executive summary
   - Three key findings
   - Evidence
   - Recommendations
   - 90-day action plan
   - KPI targets

Company:
SkillUp Academy — fictional online virtual internship and skill-learning platform.

Important:
All data is fictional and created for academic/portfolio use.
